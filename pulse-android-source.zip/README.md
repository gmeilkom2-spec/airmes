# Pulse Android wrapper

This app opens the live Pulse messenger at https://gmeilkom2-spec.github.io/airmes/ in a secure WebView. An internet connection is required. Firebase sign-in and local storage are enabled. Android asks for microphone or camera access only when the trusted Pulse website starts a call.

Build the debug APK with gradle assembleDebug from this directory. The repository GitHub Actions workflow builds and attaches the APK as a downloadable artifact.