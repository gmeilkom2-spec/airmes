package app.pulse.messenger;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Window;
import android.webkit.CookieManager;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.util.ArrayList;
import java.util.List;

public final class MainActivity extends Activity {
    private static final String APP_URL = "https://gmeilkom2-spec.github.io/airmes/";
    private static final String APP_HOST = "gmeilkom2-spec.github.io";
    private static final int MEDIA_PERMISSION_REQUEST = 42;
    private WebView webView;
    private PermissionRequest pendingWebPermission;
    private String[] pendingAndroidPermissions = new String[0];

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.setStatusBarColor(Color.rgb(35,36,40));
        window.setNavigationBarColor(Color.rgb(23,24,27));
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(35,36,40));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setSupportMultipleWindows(false);
        CookieManager cookies = CookieManager.getInstance();
        cookies.setAcceptCookie(true);
        cookies.setAcceptThirdPartyCookies(webView,true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> handleWebPermission(request));
            }
            @Override public void onPermissionRequestCanceled(PermissionRequest request) {
                if(pendingWebPermission==request) {
                    pendingWebPermission=null;
                    pendingAndroidPermissions=new String[0];
                }
            }
        });
        setContentView(webView);
        if(savedInstanceState!=null && webView.restoreState(savedInstanceState)!=null) return;
        webView.loadUrl(APP_URL);
    }

    private void handleWebPermission(PermissionRequest request) {
        Uri origin=request.getOrigin();
        if(origin==null || !"https".equals(origin.getScheme()) || !APP_HOST.equals(origin.getHost())) {
            request.deny(); return;
        }
        boolean needsAudio=false, needsCamera=false;
        for(String resource:request.getResources()) {
            if(PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)) needsAudio=true;
            else if(PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource)) needsCamera=true;
            else { request.deny(); return; }
        }
        List<String> missing=new ArrayList<>();
        if(needsAudio && !isGranted(Manifest.permission.RECORD_AUDIO)) missing.add(Manifest.permission.RECORD_AUDIO);
        if(needsCamera && !isGranted(Manifest.permission.CAMERA)) missing.add(Manifest.permission.CAMERA);
        if(missing.isEmpty()) { request.grant(request.getResources()); return; }
        if(pendingWebPermission!=null) pendingWebPermission.deny();
        pendingWebPermission=request;
        pendingAndroidPermissions=missing.toArray(new String[0]);
        requestPermissions(pendingAndroidPermissions,MEDIA_PERMISSION_REQUEST);
    }

    private boolean isGranted(String permission) {
        return Build.VERSION.SDK_INT<Build.VERSION_CODES.M || checkSelfPermission(permission)==PackageManager.PERMISSION_GRANTED;
    }

    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults) {
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if(requestCode!=MEDIA_PERMISSION_REQUEST) return;
        PermissionRequest request=pendingWebPermission;
        String[] needed=pendingAndroidPermissions;
        pendingWebPermission=null;
        pendingAndroidPermissions=new String[0];
        if(request==null) return;
        boolean granted=true;
        for(String permission:needed) if(!isGranted(permission)) { granted=false; break; }
        if(granted) request.grant(request.getResources()); else request.deny();
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        if(webView!=null) webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override public void onBackPressed() {
        if(webView!=null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if(pendingWebPermission!=null) { pendingWebPermission.deny(); pendingWebPermission=null; }
        if(webView!=null) { webView.destroy(); webView=null; }
        super.onDestroy();
    }
}