export const giftCatalog = [
  { id: 'tree', name: 'Ёлочка', image: './gifts/tree.svg', price: 20, redeemCoins: 10, accent: '#1ba252' },
  { id: 'heart', name: 'Сердечко', image: './gifts/heart.svg', price: 35, redeemCoins: 18, accent: '#e72d3a' },
  { id: 'plane', name: 'Самолётик', image: './gifts/plane.svg', price: 50, redeemCoins: 25, accent: '#376fef' },
  { id: 'frog', name: 'Лягушонок', image: './gifts/frog.svg', price: 70, redeemCoins: 35, accent: '#169b52' },
];

export const HOURLY_COIN_AMOUNT = 10;
export const HOUR_MS = 60 * 60 * 1000;
