export const giftCatalog = [
  { id: 'tree', name: 'Ёлочка', image: './gifts/tree.svg', costCoins: 20, redeemCoins: 10, accent: '#1ba252' },
  { id: 'heart', name: 'Сердечко', image: './gifts/heart.svg', costCoins: 30, redeemCoins: 18, accent: '#e72d3a' },
  { id: 'plane', name: 'Самолётик', image: './gifts/plane.svg', costCoins: 45, redeemCoins: 25, accent: '#376fef' },
  { id: 'frog', name: 'Лягушонок', image: './gifts/frog.svg', costCoins: 60, redeemCoins: 35, accent: '#169b52' },
];

export const HOURLY_COIN_AMOUNT = 10;
export const HOUR_MS = 60 * 60 * 1000;
