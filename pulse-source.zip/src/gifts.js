export const giftCatalog = [
  { id: 'mask', name: 'Маска', image: './gifts/mask.webp', costCoins: 500, redeemCoins: 300, accent: '#c9a84c' },
  { id: 'mad-pumpkin', name: 'Безумная тыква', image: './gifts/mad-pumpkin.webp', costCoins: 25, redeemCoins: 15, accent: '#ed681c' },
  { id: 'statue-of-liberty', name: 'Статуя Свободы', image: './gifts/statue-of-liberty.webp', costCoins: 250, redeemCoins: 150, accent: '#31b999' },
  { id: 'gravestone', name: 'Надгробие', image: './gifts/gravestone.webp', costCoins: 15000, redeemCoins: 9000, accent: '#71758b' },
  { id: 'durovs-sunglasses', name: 'Очки Пупика', image: './gifts/durovs-sunglasses.webp', costCoins: 30000, redeemCoins: 18000, accent: '#474841' },
  { id: 'algorithm-cup', name: 'Кубок алгоритма', image: './gifts/algorithm-cup.webp', costCoins: 15000, redeemCoins: 9000, accent: '#3589ed' },
  { id: 'candle-lamp', name: 'Фонарь со свечой', image: './gifts/candle-lamp.webp', costCoins: 100, redeemCoins: 60, accent: '#cb8051' },
  { id: 'kitty-medallion', name: 'Медальон с котятами', image: './gifts/kitty-medallion.webp', costCoins: 500, redeemCoins: 300, accent: '#e84f9a' },
  { id: 'plush-pepe', name: 'Плюшевый Пепе', image: './gifts/plush-pepe.webp', costCoins: 2000, redeemCoins: 1200, accent: '#69ae32' },
];

export const HOURLY_COIN_AMOUNT = 10;
export const HOUR_MS = 60 * 60 * 1000;
