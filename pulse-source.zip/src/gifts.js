export const giftCatalog = [
  { id: 'tree', name: 'Ёлочка', image: './gifts/tree.svg', costCoins: 20, redeemCoins: 10, accent: '#1ba252' },
  { id: 'heart', name: 'Сердечко', image: './gifts/heart.svg', costCoins: 30, redeemCoins: 18, accent: '#e72d3a' },
  { id: 'plane', name: 'Самолётик', image: './gifts/plane.svg', costCoins: 45, redeemCoins: 25, accent: '#376fef' },
  { id: 'frog', name: 'Лягушонок', image: './gifts/frog.svg', costCoins: 60, redeemCoins: 35, accent: '#169b52' },
  { id: 'mask', name: 'Маска', image: './gifts/mask.webp', costCoins: 75, redeemCoins: 45, accent: '#c9a84c' },
  { id: 'mad-pumpkin', name: 'Безумная тыква', image: './gifts/mad-pumpkin.webp', costCoins: 90, redeemCoins: 55, accent: '#ed681c' },
  { id: 'statue-of-liberty', name: 'Статуя Свободы', image: './gifts/statue-of-liberty.webp', costCoins: 120, redeemCoins: 75, accent: '#31b999' },
  { id: 'gravestone', name: 'Надгробие', image: './gifts/gravestone.webp', costCoins: 100, redeemCoins: 60, accent: '#71758b' },
  { id: 'durovs-sunglasses', name: 'Очки Дурова', image: './gifts/durovs-sunglasses.webp', costCoins: 150, redeemCoins: 90, accent: '#474841' },
  { id: 'algorithm-cup', name: 'Кубок алгоритма', image: './gifts/algorithm-cup.webp', costCoins: 180, redeemCoins: 110, accent: '#3589ed' },
  { id: 'candle-lamp', name: 'Фонарь со свечой', image: './gifts/candle-lamp.webp', costCoins: 65, redeemCoins: 40, accent: '#cb8051' },
  { id: 'kitty-medallion', name: 'Медальон с котятами', image: './gifts/kitty-medallion.webp', costCoins: 160, redeemCoins: 95, accent: '#e84f9a' },
  { id: 'resistance-dog', name: 'Пёс сопротивления', image: './gifts/resistance-dog.webp', costCoins: 220, redeemCoins: 130, accent: '#596075' },
  { id: 'plush-pepe', name: 'Плюшевый Пепе', image: './gifts/plush-pepe.webp', costCoins: 250, redeemCoins: 150, accent: '#69ae32' },
];

export const HOURLY_COIN_AMOUNT = 10;
export const HOUR_MS = 60 * 60 * 1000;
