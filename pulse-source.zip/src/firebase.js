import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getDatabase } from 'firebase/database';

// Firebase web config is public by design. Secure access with Authentication and database.rules.json.
const firebaseConfig = {
  apiKey: 'AIzaSyB_nSjHAm1M_c8MBrToZ9GCp8fXS6DMEv8',
  authDomain: 'pypms-682bc.firebaseapp.com',
  databaseURL: 'https://pypms-682bc-default-rtdb.europe-west1.firebasedatabase.app',
  projectId: 'pypms-682bc',
  storageBucket: 'pypms-682bc.firebasestorage.app',
  messagingSenderId: '84311636378',
  appId: '1:84311636378:web:f283c2ed23f5d7e62aa223',
  measurementId: 'G-VZFCYGSJ7C'
};
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getDatabase(app);
