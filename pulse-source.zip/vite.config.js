import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
const inlineAssets = {
  name: 'inline-assets-for-github-upload',
  enforce: 'post',
  generateBundle(_options, bundle) {
    const page = bundle['index.html'];
    if (!page || page.type !== 'asset') return;
    let html = String(page.source);
    for (const [fileName, item] of Object.entries(bundle)) {
      if (item.type === 'chunk' && item.isEntry) {
        const safeCode = item.code.replace(/<\/script/gi, '<\\/script');
        html = html.replace(/\s*<script[^>]*src=["'][^"']+\.js[^"']*["'][^>]*><\/script>/, `<script type="module">${safeCode}</script>`);
        delete bundle[fileName];
      } else if (item.type === 'asset' && fileName.endsWith('.css')) {
        const css = String(item.source).replace(/<\/style/gi, '<\\/style');
        html = html.replace(/\s*<link[^>]*stylesheet[^>]*>/, `<style>${css}</style>`);
        delete bundle[fileName];
      }
    }
    page.source = html;
  }
};
export default defineConfig({ plugins: [react(), inlineAssets], base: './' });
