import { cert, initializeApp } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';
import { readFile } from 'node:fs/promises';

const [email, keyPath] = process.argv.slice(2);
if (!email || !keyPath) {
  console.error('Usage: node scripts/set-admin.mjs user@example.com path/to/service-account.json');
  process.exit(1);
}
const serviceAccount = JSON.parse(await readFile(keyPath, 'utf8'));
initializeApp({ credential: cert(serviceAccount), projectId: 'pypms-682bc' });
const user = await getAuth().getUserByEmail(email);
await getAuth().setCustomUserClaims(user.uid, { ...(user.customClaims || {}), admin: true });
console.log(`Admin access granted to ${email}. Sign out and sign in again to refresh the token.`);
